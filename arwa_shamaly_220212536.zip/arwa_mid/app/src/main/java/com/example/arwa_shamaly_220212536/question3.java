package com.example.arwa_shamaly_220212536;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;

import com.example.arwa_shamaly_220212536.databinding.ActivityQuestion3Binding;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import java.util.ArrayList;

public class question3 extends AppCompatActivity {
ActivityQuestion3Binding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityQuestion3Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ArrayList<Integer> tabs=new ArrayList<>();

        for (int i = 0; i < 501; i++) {
            tabs.add(1);
        }
        ArrayList<Fragment> fragments=new ArrayList<>();
        for (int i = 0; i < 501; i++) {
            fragments.add(new FragmentVP());
        }
        VPAdapter adapterVP=new VPAdapter(this,fragments);
        binding.vp.setAdapter(adapterVP);

        new TabLayoutMediator(binding.tb, binding.vp,
                new TabLayoutMediator.TabConfigurationStrategy() {
                    @Override
                    public void onConfigureTab(@NonNull TabLayout.Tab tab, int position) {
                        tab.setText(tabs.get(position));
                    }
                }).attach();

    }
}