package com.example.arwa_shamaly_220212536;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;

import com.example.arwa_shamaly_220212536.databinding.ActivityMainBinding;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
ActivityMainBinding binding;
ArrayList<Product> arrayList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        arrayList = new ArrayList<>();
        RoomDatabase roomDatabase = RoomDatabase.getDatabase(getBaseContext());
        binding.btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                arrayList.add(new Product(binding.etProuductName.getText().toString(),
                        Integer.parseInt(binding.etQuantityAvailable.getText().toString()),
                        binding.etHasToShow.getText().toString()));
                binding.rc.notifyAll();

                roomDatabase.productDAO().insertProduct(new Product(binding.etProuductName.getText().toString(),
                        Integer.parseInt(binding.etQuantityAvailable.getText().toString()),
                        binding.etHasToShow.getText().toString()));

            }
        });
        List<Product> productASC = (List<Product>) roomDatabase.productDAO().getProductASC();
        ProductAdapter productAdapter = new ProductAdapter(arrayList);
       // binding.rc.setAdapter(productAdapter);
        //binding.rc.setAdapter(productASC);
        binding.rc.setLayoutManager(new LinearLayoutManager(getBaseContext()
                , RecyclerView.VERTICAL,false));
    }
}